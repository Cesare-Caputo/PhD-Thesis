  
from setuptools import setup

setup(name='gym_garage',
      version='0.0.1',
      install_requires=['gym']  # And any other dependencies needed
)
