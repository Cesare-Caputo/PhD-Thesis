# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 14:23:31 2020

@author: cesa_
"""

class Design_Vector:
    def __init__(self, flex, a1_4, a9_12, a17_20, dr, ft, f0):
        self.flex = flex
        self.a1_4 = a1_4
        self.a9_12 = a9_12
        self.a17_20 = a17_20
        self.dr = dr
        self.ft = ft
        self.f0 = f0

        
        
