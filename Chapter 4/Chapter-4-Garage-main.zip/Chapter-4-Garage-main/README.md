# Chapter 4 garage
Codes for garage Flexibility Decision Rules via Genetic Algorithm Flexibility Decision Rules, Stochastichally optimal inflexible benchmark, Dynamic Programming Sample Average Approximation and Reinforcement Learning implementations
